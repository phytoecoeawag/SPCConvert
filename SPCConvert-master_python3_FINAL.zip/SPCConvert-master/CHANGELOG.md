# SPCConvert Change Log


## 1.10

- extensive object features are calculated (based on both shape and various colour intensity)
- all calculated features are exported as TSV file

## 1.01.a

- initial public version of the software
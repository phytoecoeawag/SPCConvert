import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import glob
import os
import sys
import time
import shutil
import spcconvert
import logging
from logging.handlers import RotatingFileHandler
from logging import handlers

# settings
send_email = True



        
# Send a simple email with subject and message 
def send_email_notice(toaddr,fromaddr,subject,message,serv='smtp.eawag.ch'): 
 
    if not send_email:
        return
 
    msg = MIMEMultipart()
    msg['From'] = fromaddr
    msg['To'] = toaddr
    msg['Subject'] = subject
     
    body = message
    msg.attach(MIMEText(body, 'plain'))
     
    server = smtplib.SMTP(serv, 587)
    text = msg.as_string()
    server.sendmail(fromaddr, toaddr, text)
    server.quit()

# Test sending an email
def test_send_email_notice():

    if send_email:
        send_email_notice('christian.ebi@eawag.ch','christian.ebi@eawag.ch','this is a test','test')
    else:
        print("Email not enabled, change settings")
    
if __name__ == "__main__":

    # setup logging
    test_send_email_notice()